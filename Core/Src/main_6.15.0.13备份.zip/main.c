/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body (Multi-timer axis control 2025-06-13)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "stm32f4xx.h"

/* === AXIS <-> TIMER / CHANNEL 统一定义 ======================== */
#define Y_HTIM        htim1
#define Y_CHANNEL     TIM_CHANNEL_1

#define Z_HTIM        htim2
#define Z_CHANNEL     TIM_CHANNEL_1

#define X_HTIM        htim8
#define X_CHANNEL_A   TIM_CHANNEL_1   // 双电机 A
#define X_CHANNEL_B   TIM_CHANNEL_2   // 双电机 B
/* ============================================================= */
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef enum {
    AXIS_X,
    AXIS_Y,
    AXIS_Z
} Axis_t;

typedef enum {
    DIR_NEGATIVE = 0,
    DIR_POSITIVE = 1
} Direction_t;

typedef enum {
    STATE_IDLE,
    STATE_HOMING,
    STATE_WAIT_HOMING,
    STATE_MOVE_X,
    STATE_WAIT_X,
    STATE_MOVE_Y,
    STATE_WAIT_Y,
    STATE_MOVE_Z,
    STATE_WAIT_Z
} SystemState_t;

typedef struct {
    int32_t x, y, z;
    uint32_t duration_ms;
} MotionCommand;

/* Structure to manage state of each PWM channel for pulse generation */
typedef struct {
    volatile uint8_t  active;              /* Is this channel generating pulses?   */
    volatile uint32_t stop_time;           /* Tick time to stop the generation    */
    volatile uint8_t  limit_triggered;     /* Flag to indicate limit switch hit   */
    volatile uint32_t total_pulses;        /* Total pulses (for future use)       */
} PWM_Pulse_State;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define UART_RX_BUFFER_SIZE 512
#define UART_TX_BUFFER_SIZE 512
#define CMD_QUEUE_LENGTH 8
#define HOMING_FREQUENCY   5000
#define HOMING_DURATION_MS 200000
#define MIN_FREQUENCY_HZ   100
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim8;

UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
/* Coordinate System */
volatile int32_t current_pos_x = 0;
volatile int32_t current_pos_y = 0;
volatile int32_t current_pos_z = 0;
volatile int32_t target_pos_x  = 0;
volatile int32_t target_pos_y  = 0;
volatile int32_t target_pos_z  = 0;

/* Array to hold state for the 4 channels (Y, Z, X-A, X-B) */
volatile PWM_Pulse_State pwm_pulse_states[4];

/* Command queue and state machine variables */
volatile MotionCommand cmdQueue[CMD_QUEUE_LENGTH];
volatile uint8_t cmdHead = 0, cmdTail = 0;
SystemState_t systemState = STATE_IDLE;
MotionCommand currentCmd;

/* UART receive variables */
uint8_t rxBuffer[UART_RX_BUFFER_SIZE];
uint8_t rxIndex = 0;
uint8_t rxChar;

/* System flags */
volatile uint8_t systemHomed = 0;
volatile uint8_t homingInProgress = 0;   // 归零中标志
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM8_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */
/* User function prototypes */
void PWM_Pulse_Init(void);
static void UpdateAxisFrequency(TIM_HandleTypeDef *htim, uint32_t freq_hz);
void HomeAxes(void);
static void StopMotor(Axis_t axis);
void PWM_Pulse_Handler(void);
void PC0_Interrupt_Handler(void);
void PC1_Interrupt_Handler(void);
void PC2_Interrupt_Handler(void);
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin);

/* Command queue functions */
uint8_t CmdQueue_IsEmpty(void);
uint8_t CmdQueue_IsFull(void);
uint8_t CmdQueue_Enqueue(MotionCommand cmd);
uint8_t CmdQueue_Dequeue(MotionCommand *cmd);

/* Command parsing and state machine */
uint8_t ParseCommand(char *buffer, MotionCommand *cmd);
void MotionStateMachine_Run(void);

/* Helper functions */
/* New functions for multi-axis movement */
uint8_t MoveToXYZ(int32_t target_x, int32_t target_y, int32_t target_z, uint32_t max_speed_steps_per_sec);
void WaitForMoveComplete(void);
uint8_t IsAnyAxisMoving(void);
void GetCurrentPosition(int32_t *pos_x, int32_t *pos_y, int32_t *pos_z);

/* Unified timer reset function for single axis */
static void ResetAxisTimer(TIM_HandleTypeDef *htim, uint32_t channel);

/* New function for resetting all timers */
static void ResetAllTimers(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM8_Init();
  MX_USART3_UART_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  PWM_Pulse_Init();
  HAL_TIM_Base_Start(&htim1); // Start the timer base
  HAL_TIM_Base_Start(&htim2); // Start the timer base
  HAL_TIM_Base_Start(&htim8); // Start the timer base

  // 1. Home all axes
  HomeAxes();
  HAL_Delay(2000); // Increased wait time to ensure homing is complete

  // --- Combined XYZ Movement Test ---
  // Move to (5000, 5000, 5000)
  MoveToXYZ(5000, 5000, 5000, 5000);
  WaitForMoveComplete();
  HAL_Delay(1000);

  // Move to (10000, 8000, 6000)
  MoveToXYZ(10000, 8000, 6000, 5000);
  WaitForMoveComplete();
  HAL_Delay(1000);

  MoveToXYZ(1000, 1000, 1000, 5000);
  WaitForMoveComplete();
  HAL_Delay(1000);

  MoveToXYZ(8000, 8000, 6000, 5000);
  WaitForMoveComplete();
  HAL_Delay(1000);

  MoveToXYZ(5000, 5000, 5000, 5000);
  WaitForMoveComplete();
  HAL_Delay(1000);

  // Move to (10000, 8000, 6000)
  MoveToXYZ(10000, 8000, 6000, 5000);
  WaitForMoveComplete();
  HAL_Delay(1000);

  MoveToXYZ(1000, 1000, 1000, 5000);
  WaitForMoveComplete();
  HAL_Delay(1000);

  HomeAxes();
  HAL_Delay(2000); // Increased wait time to ensure homing is complete
	
  MoveToXYZ(8000, 8000, 6000, 5000);
  WaitForMoveComplete();
  HAL_Delay(1000);

  MoveToXYZ(5000, 5000, 5000, 5000);
  WaitForMoveComplete();
  HAL_Delay(1000);

  // Move to (10000, 8000, 6000)
  MoveToXYZ(10000, 8000, 6000, 5000);
  WaitForMoveComplete();
  HAL_Delay(1000);

  MoveToXYZ(1000, 1000, 1000, 5000);
  WaitForMoveComplete();
  HAL_Delay(1000);
	
  HomeAxes();
  HAL_Delay(2000); // Increased wait time to ensure homing is complete

  MoveToXYZ(8000, 8000, 6000, 5000);
  WaitForMoveComplete();
  HAL_Delay(1000);

  MoveToXYZ(5000, 5000, 5000, 5000);
  WaitForMoveComplete();
  HAL_Delay(1000);
	
  HomeAxes();
  HAL_Delay(2000); // Increased wait time to ensure homing is complete

  // Move to (10000, 8000, 6000)
  MoveToXYZ(10000, 8000, 6000, 5000);
  WaitForMoveComplete();
  HAL_Delay(1000);

  MoveToXYZ(1000, 1000, 1000, 5000);
  WaitForMoveComplete();
  HAL_Delay(1000);

  MoveToXYZ(8000, 8000, 6000, 5000);
  WaitForMoveComplete();
  HAL_Delay(1000);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  // Test sequence complete, do nothing.
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 167;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 999;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 167;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 999;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM8 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM8_Init(void)
{

  /* USER CODE BEGIN TIM8_Init 0 */

  /* USER CODE END TIM8_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM8_Init 1 */

  /* USER CODE END TIM8_Init 1 */
  htim8.Instance = TIM8;
  htim8.Init.Prescaler = 167;
  htim8.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim8.Init.Period = 999;
  htim8.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim8.Init.RepetitionCounter = 0;
  htim8.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim8) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim8, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim8) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim8, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim8, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim8, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim8, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim8, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim8, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM8_Init 2 */

  /* USER CODE END TIM8_Init 2 */
  HAL_TIM_MspPostInit(&htim8);

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  __HAL_RCC_SYSCFG_CLK_ENABLE();
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC0 PC1 PC2 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PC3 */
  GPIO_InitStruct.Pin = GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PB4 PB5 PB6 PB7 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_IRQn, 0, 0);
  HAL_NVIC_SetPriority(EXTI1_IRQn, 0, 0);
  HAL_NVIC_SetPriority(EXTI2_IRQn, 0, 0);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/**
  * @brief  Initialize PWM pulse state structures
  * @retval None
  */
void PWM_Pulse_Init(void)
{
    for (int i = 0; i < 4; i++) {
        pwm_pulse_states[i].active           = 0;
        pwm_pulse_states[i].stop_time        = 0;
        pwm_pulse_states[i].limit_triggered  = 0;
        pwm_pulse_states[i].total_pulses     = 0;
    }
}

/**
  * @brief  设置指定定时器的 PWM 频率
  * @note   16-bit 自动寻合适 PSC & ARR，shadow→UG 立即生效
  */
static void UpdateAxisFrequency(TIM_HandleTypeDef *htim, uint32_t freq_hz)
{
    if (freq_hz < MIN_FREQUENCY_HZ)   freq_hz = MIN_FREQUENCY_HZ;
    if (freq_hz > 50000)              freq_hz = 50000;

    uint32_t tim_clk;
    
    // Explicitly determine clock source for each timer
    if (htim->Instance == TIM2 || htim->Instance == TIM3 || htim->Instance == TIM4 || 
        htim->Instance == TIM5 || htim->Instance == TIM6 || htim->Instance == TIM7) {
        tim_clk = 84000000; // APB1 timers
    } else { // TIM1, TIM8, TIM9-TIM14 are APB2 timers
        tim_clk = 168000000; // APB2 timers
    }

    uint64_t target  = (uint64_t)tim_clk / freq_hz;

    uint16_t psc = 0, arr = 0;
    for (uint16_t tpsc = 0; tpsc < 0xFFFF; ++tpsc) {
        uint32_t tarr = target / (tpsc + 1);
        if (tarr > 0 && tarr <= 0xFFFF) { psc = tpsc; arr = tarr - 1; break; }
    }

    // Save current CCER state
    uint32_t ccer_backup = htim->Instance->CCER;
    
    HAL_TIM_Base_Stop(htim);
    __HAL_TIM_SET_PRESCALER(htim, psc);
    __HAL_TIM_SET_AUTORELOAD(htim, arr);
    
    // Do not clear CCER, but temporarily disable then restore
    htim->Instance->CCER = 0;          // Temporarily disable all channels
    __HAL_TIM_SET_COUNTER(htim, 0);
    htim->Instance->EGR = TIM_EGR_UG;  // Force load new parameters
    htim->Instance->CCER = ccer_backup; // Restore previous channel enable state
    
    HAL_TIM_Base_Start(htim);
}

/**
  * @brief  Stop motor movement for specified axis
  * @param  axis: Axis to stop
  * @retval None
  */
static void StopMotor(Axis_t axis)
{
    switch (axis) {
    case AXIS_Y:
        HAL_TIM_PWM_Stop(&Y_HTIM, Y_CHANNEL);
        pwm_pulse_states[0].active = pwm_pulse_states[0].limit_triggered = 0;
        break;
    case AXIS_Z:
        HAL_TIM_PWM_Stop(&Z_HTIM, Z_CHANNEL);
        pwm_pulse_states[1].active = pwm_pulse_states[1].limit_triggered = 0;
        break;
    case AXIS_X:
        HAL_TIM_PWM_Stop(&X_HTIM, X_CHANNEL_A);
        HAL_TIM_PWM_Stop(&X_HTIM, X_CHANNEL_B);
        pwm_pulse_states[2].active = pwm_pulse_states[3].active = 0;
        pwm_pulse_states[2].limit_triggered = pwm_pulse_states[3].limit_triggered = 0;
        break;
    }
}

/**
  * @brief  同时移动三轴到指定坐标位置
  * @param  tx: X轴目标位置
  * @param  ty: Y轴目标位置
  * @param  tz: Z轴目标位置
  * @param  vmax: 主导轴的最大移动速度（步/秒）
  * @retval 0: 成功, 1: 有轴正在运行无法启动, 2: 无需移动, 3: PWM启动失败
  */
uint8_t MoveToXYZ(int32_t tx, int32_t ty, int32_t tz, uint32_t vmax)
{
    // Reset all timers, not just TIM8
    ResetAllTimers();
    
    if (IsAnyAxisMoving()) return 1;

    int32_t dx = tx - current_pos_x,  sx = abs(dx);
    int32_t dy = ty - current_pos_y,  sy = abs(dy);
    int32_t dz = tz - current_pos_z,  sz = abs(dz);
    if (!sx && !sy && !sz) return 2;

    uint32_t freq = vmax ? vmax : 5000;
    if (freq < MIN_FREQUENCY_HZ) freq = MIN_FREQUENCY_HZ;
    if (freq > 50000) freq = 50000;
    
    /* 频率分别写进三个定时器 */
    if (sx) UpdateAxisFrequency(&X_HTIM, freq);
    if (sy) UpdateAxisFrequency(&Y_HTIM, freq);
    if (sz) UpdateAxisFrequency(&Z_HTIM, freq);

    // Set direction pins first
    if (sx > 0) {
        Direction_t direction_x = (dx > 0) ? DIR_POSITIVE : DIR_NEGATIVE;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, (direction_x == DIR_POSITIVE) ? GPIO_PIN_SET : GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, (direction_x == DIR_POSITIVE) ? GPIO_PIN_RESET : GPIO_PIN_SET);
    }

    if (sy > 0) {
        Direction_t direction_y = (dy > 0) ? DIR_POSITIVE : DIR_NEGATIVE;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, (direction_y == DIR_POSITIVE) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    }

    if (sz > 0) {
        Direction_t direction_z = (dz > 0) ? DIR_POSITIVE : DIR_NEGATIVE;
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, (direction_z == DIR_NEGATIVE) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    }

    // 增加延迟以确保方向信号和定时器状态都稳定
    HAL_Delay(2);  // Changed from 20ms to 2ms

    uint32_t t0 = HAL_GetTick();
    /*―――― Y 轴 ――――*/
    if (sy) {
        pwm_pulse_states[0].active = 1;
        pwm_pulse_states[0].limit_triggered = 0;
        pwm_pulse_states[0].stop_time = t0 + (sy*1000)/freq;
        HAL_TIM_PWM_Start(&Y_HTIM, Y_CHANNEL);
        __HAL_TIM_SET_COMPARE(&Y_HTIM, Y_CHANNEL, (__HAL_TIM_GET_AUTORELOAD(&Y_HTIM)+1)/2);
    }
    /*―――― Z 轴 ――――*/
    if (sz) {
        pwm_pulse_states[1].active = 1;
        pwm_pulse_states[1].limit_triggered = 0;
        pwm_pulse_states[1].stop_time = t0 + (sz*1000)/freq;
        HAL_TIM_PWM_Start(&Z_HTIM, Z_CHANNEL);
        __HAL_TIM_SET_COMPARE(&Z_HTIM, Z_CHANNEL, (__HAL_TIM_GET_AUTORELOAD(&Z_HTIM)+1)/2);
    }
    /*―――― X 轴双电机 ――――*/
    if (sx) {
        pwm_pulse_states[2].active = pwm_pulse_states[3].active = 1;
        pwm_pulse_states[2].limit_triggered = pwm_pulse_states[3].limit_triggered = 0;
        pwm_pulse_states[2].stop_time = pwm_pulse_states[3].stop_time = t0 + (sx*1000)/freq;
        HAL_TIM_PWM_Start(&X_HTIM, X_CHANNEL_A);
        HAL_TIM_PWM_Start(&X_HTIM, X_CHANNEL_B);
        uint16_t duty = (__HAL_TIM_GET_AUTORELOAD(&X_HTIM)+1)/2;
        __HAL_TIM_SET_COMPARE(&X_HTIM, X_CHANNEL_A, duty);
        __HAL_TIM_SET_COMPARE(&X_HTIM, X_CHANNEL_B, duty);
    }

    /* 成功后写目标坐标 */
    if (sx) target_pos_x = tx;
    if (sy) target_pos_y = ty;
    if (sz) target_pos_z = tz;
    return 0;

error:
    StopMotor(AXIS_X); StopMotor(AXIS_Y); StopMotor(AXIS_Z);
    return 3;
}

/**
  * @brief  等待三轴移动完成
  * @retval None
  */
void WaitForMoveComplete(void)
{
    while (pwm_pulse_states[0].active ||  // Y轴
           pwm_pulse_states[1].active ||  // Z轴
           pwm_pulse_states[2].active ||  // X轴 motor A
           pwm_pulse_states[3].active) {  // X轴 motor B
        PWM_Pulse_Handler();
        HAL_Delay(1);
    }
}

/**
  * @brief  检查是否有轴正在移动
  * @retval 1: 有轴在移动, 0: 所有轴都停止
  */
uint8_t IsAnyAxisMoving(void)
{
    return (pwm_pulse_states[0].active ||  // Y轴
            pwm_pulse_states[1].active ||  // Z轴
            pwm_pulse_states[2].active ||  // X轴 motor A
            pwm_pulse_states[3].active);   // X轴 motor B
}

/**
  * @brief  获取当前三轴位置
  * @param  pos_x: X轴位置指针
  * @param  pos_y: Y轴位置指针
  * @param  pos_z: Z轴位置指针
  * @retval None
  */
void GetCurrentPosition(int32_t *pos_x, int32_t *pos_y, int32_t *pos_z)
{
    if (pos_x) *pos_x = current_pos_x;
    if (pos_y) *pos_y = current_pos_y;
    if (pos_z) *pos_z = current_pos_z;
}

/**
  * @brief  Home all axes by moving to limit switches
  * @retval None
  */
void HomeAxes(void)
{
    homingInProgress = 1;    // —— 开始归零 —— 

    /* —— 在归零过程中才使能限位开关中断 —— */
    __HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2);
    HAL_NVIC_EnableIRQ(EXTI0_IRQn);
    HAL_NVIC_EnableIRQ(EXTI1_IRQn);
    HAL_NVIC_EnableIRQ(EXTI2_IRQn);

    // Set homing indicator high
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET);

    // Initialize all direction pins to a known state (homing direction)
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET); // Y-axis negative direction
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);   // Z-axis negative direction (as per original code)
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET); // X-axis negative direction
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);   // X-axis negative direction

    HAL_Delay(10); // Give direction signals time to stabilize

    // Set timer frequency for each axis
    UpdateAxisFrequency(&X_HTIM, HOMING_FREQUENCY);
    UpdateAxisFrequency(&Y_HTIM, HOMING_FREQUENCY);
    UpdateAxisFrequency(&Z_HTIM, HOMING_FREQUENCY);

    uint8_t x_needs_homing = 0;
    uint8_t y_needs_homing = 0;
    uint8_t z_needs_homing = 0;
    
    uint32_t current_time_for_homing = HAL_GetTick(); // Get common start time for homing pulses

    // Check and start X-axis homing
    if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_0) == GPIO_PIN_SET) {
        x_needs_homing = 1;
        // Manually set PWM state (active, total_pulses, stop_time)
        pwm_pulse_states[2].limit_triggered = 0;
        pwm_pulse_states[2].total_pulses = 999999;
        pwm_pulse_states[2].stop_time = current_time_for_homing + HOMING_DURATION_MS;

        pwm_pulse_states[3].limit_triggered = 0;
        pwm_pulse_states[3].total_pulses = 999999;
        pwm_pulse_states[3].stop_time = current_time_for_homing + HOMING_DURATION_MS;

        HAL_TIM_PWM_Start(&X_HTIM, X_CHANNEL_A);
        HAL_TIM_PWM_Start(&X_HTIM, X_CHANNEL_B);
        pwm_pulse_states[2].active = 1;
        pwm_pulse_states[3].active = 1;
        uint32_t arr_val = __HAL_TIM_GET_AUTORELOAD(&X_HTIM);
        uint16_t pulse = (arr_val + 1) / 2;
        __HAL_TIM_SET_COMPARE(&X_HTIM, X_CHANNEL_A, pulse);
        __HAL_TIM_SET_COMPARE(&X_HTIM, X_CHANNEL_B, pulse);
    } else {
        // Already at home position
        current_pos_x = 0;
        target_pos_x = 0;
    }

    // Check and start Y-axis homing
    if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_1) == GPIO_PIN_SET) {
        y_needs_homing = 1;
        pwm_pulse_states[0].limit_triggered = 0;
        pwm_pulse_states[0].total_pulses = 999999;
        pwm_pulse_states[0].stop_time = current_time_for_homing + HOMING_DURATION_MS;

        HAL_TIM_PWM_Start(&Y_HTIM, Y_CHANNEL);
        pwm_pulse_states[0].active = 1;
        uint32_t arr_val = __HAL_TIM_GET_AUTORELOAD(&Y_HTIM);
        uint16_t pulse = (arr_val + 1) / 2;
        __HAL_TIM_SET_COMPARE(&Y_HTIM, Y_CHANNEL, pulse);
    } else {
        current_pos_y = 0;
        target_pos_y = 0;
    }

    // Check and start Z-axis homing
    if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_2) == GPIO_PIN_SET) {
        z_needs_homing = 1;
        pwm_pulse_states[1].limit_triggered = 0;
        pwm_pulse_states[1].total_pulses = 999999;
        pwm_pulse_states[1].stop_time = current_time_for_homing + HOMING_DURATION_MS;

        HAL_TIM_PWM_Start(&Z_HTIM, Z_CHANNEL);
        pwm_pulse_states[1].active = 1;
        uint32_t arr_val = __HAL_TIM_GET_AUTORELOAD(&Z_HTIM);
        uint16_t pulse = (arr_val + 1) / 2;
        __HAL_TIM_SET_COMPARE(&Z_HTIM, Z_CHANNEL, pulse);
    } else {
        current_pos_z = 0;
        target_pos_z = 0;
    }

    // Wait until all axes that need homing are completed
    while (1) {
        PWM_Pulse_Handler();

        // Check if all axes that needed homing are now complete
        uint8_t all_complete = 1;

        // Check X-axis completion (both channels must be inactive)
        if (x_needs_homing && (pwm_pulse_states[2].active || pwm_pulse_states[3].active)) {
            all_complete = 0;
        }

        // Check Y-axis completion
        if (y_needs_homing && pwm_pulse_states[0].active) {
            all_complete = 0;
        }

        // Check Z-axis completion
        if (z_needs_homing && pwm_pulse_states[1].active) {
            all_complete = 0;
        }

        // Exit loop when all axes are complete
        if (all_complete) {
            break;
        }

        HAL_Delay(1);
    }

    // After homing, ensure all direction pins are in a known (reset) state
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);

    /* —— 归零完成 —— */
    homingInProgress = 0;    // —— 结束归零 —— 
    systemHomed = 1;         // （可选：标记已完成一次归零）

    // Set homing indicator low after all axes are homed
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET);

    /* —— 归零完成后关闭限位开关中断 —— */
    HAL_NVIC_DisableIRQ(EXTI0_IRQn);
    HAL_NVIC_DisableIRQ(EXTI1_IRQn);
    HAL_NVIC_DisableIRQ(EXTI2_IRQn);
}

/**
  * @brief  Handle PWM pulse generation
  * @retval None
  */
void PWM_Pulse_Handler(void)
{
    uint32_t current_tick = HAL_GetTick();

    // Y-axis stop check
    if (pwm_pulse_states[0].active && !pwm_pulse_states[0].limit_triggered) {
        if (current_tick >= pwm_pulse_states[0].stop_time) {
            StopMotor(AXIS_Y);
            current_pos_y = target_pos_y;
        }
    }

    // Z-axis stop check
    if (pwm_pulse_states[1].active && !pwm_pulse_states[1].limit_triggered) {
        if (current_tick >= pwm_pulse_states[1].stop_time) {
            StopMotor(AXIS_Z);
            current_pos_z = target_pos_z;
        }
    }

    // X-axis stop check
    if ((pwm_pulse_states[2].active || pwm_pulse_states[3].active) &&
        !pwm_pulse_states[2].limit_triggered && !pwm_pulse_states[3].limit_triggered) {

        uint8_t should_stop_x = 0;
        if ((pwm_pulse_states[2].active && current_tick >= pwm_pulse_states[2].stop_time) ||
            (pwm_pulse_states[3].active && current_tick >= pwm_pulse_states[3].stop_time)) {
            should_stop_x = 1;
        }

        if (should_stop_x) {
            StopMotor(AXIS_X);
            current_pos_x = target_pos_x;
        }
    }
}

/**
  * @brief  EXTI line detection callback.
  * @param  GPIO_Pin: Specifies the pins connected EXTI line
  * @retval None
  */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    switch (GPIO_Pin) {
    case GPIO_PIN_0:  PC0_Interrupt_Handler(); break;
    case GPIO_PIN_1:  PC1_Interrupt_Handler(); break;
    case GPIO_PIN_2:  PC2_Interrupt_Handler(); break;
    }
}

/* Unified timer reset function for single axis */
static void ResetAxisTimer(TIM_HandleTypeDef *htim, uint32_t channel)
{
    HAL_TIM_PWM_Stop(htim, channel);
    htim->Instance->CCER = 0;
    
    // Handle BDTR only for advanced timers (TIM1, TIM8)
    if (htim->Instance == TIM1 || htim->Instance == TIM8) {
        htim->Instance->BDTR &= ~TIM_BDTR_MOE;
    }
    
    __HAL_TIM_SET_COUNTER(htim, 0);
}

/* New function for resetting all timers */
static void ResetAllTimers(void)
{
    ResetAxisTimer(&Y_HTIM, Y_CHANNEL);
    ResetAxisTimer(&Z_HTIM, Z_CHANNEL);
    ResetAxisTimer(&X_HTIM, X_CHANNEL_A);
    ResetAxisTimer(&X_HTIM, X_CHANNEL_B);
}

void PC0_Interrupt_Handler(void)
{
    // X 轴限位触发
    pwm_pulse_states[2].limit_triggered = 1;
    pwm_pulse_states[3].limit_triggered = 1;
    StopMotor(AXIS_X);

    // 不论何时都清 current_pos
    current_pos_x = 0;

    // 仅在归零过程中才清 target_pos
    if (homingInProgress) {
        target_pos_x = 0;
    }
}

/**
  * @brief  PC1 interrupt handler function (Y-Axis Limit Switch).
  * @retval None
  */
void PC1_Interrupt_Handler(void)
{
    // Y 轴限位触发
    pwm_pulse_states[0].limit_triggered = 1;
    StopMotor(AXIS_Y);

    current_pos_y = 0;
    if (homingInProgress) {
        target_pos_y = 0;
    }
}

/**
  * @brief  PC2 interrupt handler function (Z-Axis Limit Switch).
  * @retval None
  */
void PC2_Interrupt_Handler(void)
{
    // Z 轴限位触发
    pwm_pulse_states[1].limit_triggered = 1;
    StopMotor(AXIS_Z);

    current_pos_z = 0;
    if (homingInProgress) {
        target_pos_z = 0;
    }
}

/* Command queue functions */
uint8_t CmdQueue_IsEmpty(void)
{
    return (cmdHead == cmdTail);
}

uint8_t CmdQueue_IsFull(void)
{
    return (((cmdHead + 1) % CMD_QUEUE_LENGTH) == cmdTail);
}

uint8_t CmdQueue_Enqueue(MotionCommand cmd)
{
    if (CmdQueue_IsFull()) {
        return 0; // Queue full
    }
    cmdQueue[cmdHead] = cmd;
    cmdHead = (cmdHead + 1) % CMD_QUEUE_LENGTH;
    return 1;
}

uint8_t CmdQueue_Dequeue(MotionCommand *cmd)
{
    if (CmdQueue_IsEmpty()) {
        return 0; // Queue empty
    }
    *cmd = cmdQueue[cmdTail];
    cmdTail = (cmdTail + 1) % CMD_QUEUE_LENGTH;
    return 1;
}

/* Command parsing and state machine */
uint8_t ParseCommand(char *buffer, MotionCommand *cmd)
{
    // Implementation of ParseCommand function
    return 0; // Placeholder return, actual implementation needed
}

void MotionStateMachine_Run(void)
{
    // Implementation of MotionStateMachine_Run function
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
